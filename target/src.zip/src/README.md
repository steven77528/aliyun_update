# 使用说明（IP 同步）

## 配置方式（三文件）

推荐使用三份配置文件：

- 基础配置：`config/base.json`
- 阿里云配置：`config/aliyun.yaml`
- 通知配置：`config/notify.json`

并通过环境变量入口指定：

```dotenv
BASE_CONFIG_FILE=./config/base.json
ALIYUN_CONFIG_FILE=./config/aliyun.yaml
NOTIFY_CONFIG_FILE=./config/notify.json
```

`src/.env.example` 已精简为上述入口模式。

## 阿里云配置（YAML）

推荐通过 `ALIYUN_CONFIG_FILE` 指向 YAML 配置文件，支持多账号、多安全组、多规则：

```yaml
accounts:
  - account: "账号1"
    region_id: "cn-hangzhou"
    access_key_id: "your_access_key_id"
    access_key_secret: "your_access_key_secret"
    security_groups:
      - security_group_id: "sg-12345678"
        alias: "安全组1"
        rules:
          - rule_id: "sgr-12345678"
            alias: "规则1"
```

说明：
- `alias/name` 会在日志与通知邮件中展示，提升可读性。
- 若未设置 `ALIYUN_CONFIG_FILE`，仍可兼容旧的环境变量配置方式。

## 基础配置（JSON）

`config/base.json` 示例：

```json
{
  "check_interval_seconds": 3600,
  "log_retention_days": 7,
  "ip_sources": [
    "https://api64.ipify.org",
    "https://ifconfig.me/ip",
    "https://checkip.amazonaws.com"
  ]
}
```

## SMTP 汇总通知配置（JSON）

`config/notify.json` 核心字段：

- `enabled`：是否启用通知（`true/false`）
- `smtp_host` / `smtp_port` / `smtp_username` / `smtp_password`
- `smtp_use_tls`：是否启用 TLS
- `email_from` / `email_to`
- `retry_count` / `rate_limit_seconds`

## 通知行为

- 单轮执行中存在安全组更新尝试时，输出 `step4` 日志并发送（或尝试发送）1 封汇总邮件。
- 邮件正文逐条展示每条目标记录结果（`success/failed`）。
- 邮件正文会展示规则名称（`name/alias`）。
- 发送失败会按 `NOTIFY_RETRY_COUNT` 重试；超过重试上限后记录失败并走既有告警通道。

## 常见故障排查

1. SMTP 认证失败：检查用户名/密码（部分服务商需“授权码”而非登录密码）。
2. TLS/端口不匹配：例如 `587 + TLS(true)`，若使用 `25` 需确认服务商策略。
3. 收件人为空：`NOTIFY_EMAIL_TO` 必须至少包含一个邮箱地址。
4. 命中限频：检查 `NOTIFY_RATE_LIMIT_SECONDS` 与告警状态文件时间戳。

## 安全建议

- 凭证仅通过环境变量注入，不写入代码或仓库。
- 日志中禁止输出完整密钥、SMTP 密码与原始敏感堆栈。

## 日志文件与保留策略

- 日志文件按天命名：`ip_sync_YYYYMMDD.log`。
- 默认保留最近 7 天日志（可通过 `LOG_RETENTION_DAYS` 调整）。

## Docker 构建与运行

1. 构建镜像：

```bash
docker compose -f docker-compose.yml build
```

2. 单次执行：

```bash
docker compose -f docker-compose.yml up --abort-on-container-exit
```

3. 导出镜像压缩包到 `target/`：

```bash
mkdir -p ../target && docker save timer-check-update-ip-sync:latest -o ../target/ip-sync_latest.tar
```

## 目录兼容说明

- 当前测试代码位于 `src/tests/`。
- 为兼容现有执行方式，暂未物理迁移到仓库根 `tests/`，后续可按发布节奏迁移。

## 系统信息
当前系统为macos，终端配置为zsh，使用的shell工具为ohmyzsh，编辑器为vscode
