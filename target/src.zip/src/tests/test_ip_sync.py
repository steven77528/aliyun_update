import os
import sys
import tempfile
import unittest
import importlib.util
from pathlib import Path
from unittest.mock import patch


BASE_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE_DIR))

import ip_sync  # noqa: E402


class DummyResp:
    def __init__(self, text: str):
        self._text = text

    def read(self):
        return self._text.encode("utf-8")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return False


class TestIpConsensus(unittest.TestCase):
    def test_majority(self):
        values = {
            "https://a": "1.1.1.1",
            "https://b": "1.1.1.1",
            "https://c": "2.2.2.2",
        }

        def fake_urlopen(req, timeout):
            _ = timeout
            return DummyResp(values[req.full_url])

        with patch("ip_sync.urlopen", side_effect=fake_urlopen):
            ip, status, errors = ip_sync.resolve_ip_consensus(list(values.keys()), 3)
            self.assertEqual("majority", status)
            self.assertEqual("1.1.1.1", ip)
            self.assertEqual({}, errors)

    def test_inconsistent(self):
        values = {
            "https://a": "1.1.1.1",
            "https://b": "2.2.2.2",
        }

        def fake_urlopen(req, timeout):
            _ = timeout
            return DummyResp(values[req.full_url])

        with patch("ip_sync.urlopen", side_effect=fake_urlopen):
            ip, status, _ = ip_sync.resolve_ip_consensus(list(values.keys()), 3)
            self.assertIsNone(ip)
            self.assertEqual("inconsistent", status)

    def test_all_failed(self):
        def fake_urlopen(req, timeout):
            _ = (req, timeout)
            raise OSError("boom")

        with patch("ip_sync.urlopen", side_effect=fake_urlopen):
            ip, status, errors = ip_sync.resolve_ip_consensus(["https://a", "https://b"], 3)
            self.assertIsNone(ip)
            self.assertEqual("all_sources_failed", status)
            self.assertEqual(2, len(errors))


class TestConfigAndRetry(unittest.TestCase):
    def test_parse_single_account_compat(self):
        env = {
            "ALIYUN_REGION": "cn-hangzhou",
            "ACCESS_KEY_ID": "id",
            "ACCESS_KEY_SECRET": "secret",
            "SECURITY_GROUP_ID": "sg-1",
            "RULE_IDENTIFIER": "sgr-1",
        }
        with patch.dict(os.environ, env, clear=False):
            accounts = ip_sync.parse_accounts_from_env()
            self.assertEqual(1, len(accounts))
            self.assertEqual("default", accounts[0].name)
            self.assertEqual(1, len(accounts[0].targets))

    def test_retry(self):
        calls = {"n": 0}

        def updater():
            calls["n"] += 1
            if calls["n"] < 3:
                return False, "x"
            return True, "ok"

        ok, attempts, msg = ip_sync.execute_update_with_retry(updater, retry_count=3, retry_backoff_seconds=0)
        self.assertTrue(ok)
        self.assertEqual(3, attempts)
        self.assertEqual("ok", msg)

    @unittest.skipUnless(importlib.util.find_spec("yaml") is not None, "PyYAML 未安装，跳过 YAML 解析测试")
    def test_parse_accounts_from_yaml_file(self):
        yaml_text = """
accounts:
  - account: "acc-a"
    region_id: "cn-hangzhou"
    access_key_id: "id-a"
    access_key_secret: "secret-a"
    security_groups:
      - security_group_id: "sg-1"
        alias: "安全组A"
        rules:
          - rule_id: "sgr-1"
            alias: "规则A"
"""
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "aliyun.yaml"
            p.write_text(yaml_text, encoding="utf-8")
            accounts = ip_sync.parse_accounts_from_yaml_file(p)

        self.assertEqual(1, len(accounts))
        self.assertEqual("acc-a", accounts[0].name)
        self.assertEqual(1, len(accounts[0].targets))
        self.assertEqual("sgr-1", accounts[0].targets[0].rule_identifier)
        self.assertEqual("规则A", accounts[0].targets[0].rule_name)

    def test_state_read_write_for_target(self):
        state = {"targets": {}}
        key = "acc-a|cn-hangzhou|sg-1:sgr-1"
        self.assertIsNone(ip_sync.get_last_ip_for_target(state, key))

        ip_sync.set_last_ip_for_target(state, key, "1.2.3.4")
        self.assertEqual("1.2.3.4", ip_sync.get_last_ip_for_target(state, key))


class TestNotifySummary(unittest.TestCase):
    def _build_cfg(self) -> ip_sync.AppConfig:
        return ip_sync.AppConfig(
            run_mode="once",
            check_interval_seconds=3600,
            ip_sources=["https://a"],
            state_file=Path("./.tmp_state.json"),
            alert_state_file=Path("./.tmp_alert_state.json"),
            lock_file=Path("./.tmp.lock"),
            request_timeout_seconds=3,
            retry_count=0,
            retry_backoff_seconds=0,
            alert_webhook_url="",
            alert_rate_limit_seconds=1,
            notify_enabled=True,
            notify_smtp_host="smtp.example.com",
            notify_smtp_port=587,
            notify_smtp_username="",
            notify_smtp_password="",
            notify_smtp_use_tls=True,
            notify_email_from="from@example.com",
            notify_email_to=["to@example.com"],
            notify_retry_count=3,
            notify_rate_limit_seconds=1,
            accounts=[],
        )

    def test_summary_disabled(self):
        cfg = self._build_cfg()
        cfg.notify_enabled = False
        status, attempts, msg = ip_sync.send_summary_notification(cfg, "1.1.1.1", [{"result": "success"}])
        self.assertEqual("skipped", status)
        self.assertEqual(0, attempts)
        self.assertEqual("disabled", msg)

    def test_summary_retry_then_success(self):
        cfg = self._build_cfg()
        calls = {"n": 0}

        def fake_send(_cfg, _subject, _body, **_kwargs):
            calls["n"] += 1
            if calls["n"] < 3:
                return False, "smtp down"
            return True, "ok"

        with patch("ip_sync.send_smtp_summary_email", side_effect=fake_send), patch("ip_sync.time.sleep", return_value=None), patch(
            "ip_sync.load_alert_state", return_value={}
        ), patch("ip_sync.save_alert_state", return_value=None):
            status, attempts, msg = ip_sync.send_summary_notification(
                cfg,
                "1.1.1.1",
                [
                    {"account": "a", "region": "r", "security_group_id": "sg", "rule_identifier": "rid", "previous_ip": "1.1.1.1", "current_ip": "2.2.2.2", "result": "success"}
                ],
            )
        self.assertEqual("sent", status)
        self.assertEqual(3, attempts)
        self.assertEqual("ok", msg)

    def test_summary_max_retry_failed(self):
        cfg = self._build_cfg()
        with patch("ip_sync.send_smtp_summary_email", return_value=(False, "smtp error")), patch(
            "ip_sync.time.sleep", return_value=None
        ), patch("ip_sync.load_alert_state", return_value={}):
            status, attempts, msg = ip_sync.send_summary_notification(
                cfg,
                "1.1.1.1",
                [
                    {"account": "a", "region": "r", "security_group_id": "sg", "rule_identifier": "rid", "previous_ip": "1.1.1.1", "current_ip": "2.2.2.2", "result": "failed", "error_summary": "x"}
                ],
            )
        self.assertEqual("failed", status)
        self.assertEqual(4, attempts)
        self.assertIn("smtp", msg)

    def test_summary_body_contains_each_result(self):
        cfg = self._build_cfg()
        captured = {"subject": "", "body": ""}

        def fake_send(_cfg, subject, body, **_kwargs):
            captured["subject"] = subject
            captured["body"] = body
            return True, "ok"

        with patch("ip_sync.send_smtp_summary_email", side_effect=fake_send):
            status, attempts, _ = ip_sync.send_summary_notification(
                cfg,
                "2.2.2.2",
                [
                    {
                        "account": "a",
                        "region": "r1",
                        "security_group_id": "sg-1",
                        "rule_identifier": "rid-1",
                        "rule_name": "规则1",
                        "previous_ip": "1.1.1.1",
                        "current_ip": "2.2.2.2",
                        "result": "success",
                    },
                    {
                        "account": "b",
                        "region": "r2",
                        "security_group_id": "sg-2",
                        "rule_identifier": "rid-2",
                        "rule_name": "规则2",
                        "previous_ip": "1.1.1.1",
                        "current_ip": "2.2.2.2",
                        "result": "failed",
                        "error_summary": "api_error:boom",
                    },
                ],
            )
        self.assertEqual("sent", status)
        self.assertEqual(1, attempts)
        self.assertEqual("[阿里云安全组自动更新]更新通知", captured["subject"])
        self.assertIn("| 1 | a | r1 | sg-1 | rid-1 | 规则1 | 1.1.1.1 | 2.2.2.2 | success | - |", captured["body"])
        self.assertIn("| 2 | b | r2 | sg-2 | rid-2 | 规则2 | 1.1.1.1 | 2.2.2.2 | failed | api_error:boom |", captured["body"])
        self.assertIn("| 序号 | 账号 | 区域 | 安全组 | 规则ID | 规则名称 | 旧IP | 新IP | 结果 | 失败摘要 |", captured["body"])

    def test_send_smtp_summary_email_supports_html(self):
        cfg = self._build_cfg()
        cfg.notify_smtp_port = 465
        with patch("ip_sync.smtplib.SMTP_SSL") as mock_ssl:
            ok, msg = ip_sync.send_smtp_summary_email(
                cfg,
                "subject",
                "plain-body",
                html_body="<html><body><table><tr><td>1</td></tr></table></body></html>",
            )
        self.assertTrue(ok)
        self.assertEqual("ok", msg)
        smtp = mock_ssl.return_value.__enter__.return_value
        sent_msg = smtp.send_message.call_args.args[0]
        self.assertTrue(sent_msg.is_multipart())

    def test_summary_rate_limited(self):
        cfg = self._build_cfg()
        cfg.notify_rate_limit_seconds = 300
        with patch("ip_sync.load_alert_state", return_value={"notify_summary_email": int(ip_sync.time.time())}), patch(
            "ip_sync.send_smtp_summary_email"
        ) as mock_send:
            status, attempts, msg = ip_sync.send_summary_notification(
                cfg,
                "2.2.2.2",
                [{"result": "success", "account": "a", "region": "r", "security_group_id": "sg", "rule_identifier": "rid", "previous_ip": "1.1.1.1", "current_ip": "2.2.2.2"}],
            )
        self.assertEqual("skipped", status)
        self.assertEqual(0, attempts)
        self.assertEqual("rate_limited", msg)
        mock_send.assert_not_called()

    def test_run_cycle_logs_step4_when_changed(self):
        cfg = self._build_cfg()
        cfg.accounts = [
            ip_sync.AccountConfig(
                name="acc",
                region_id="cn-hangzhou",
                access_key_id="id",
                access_key_secret="secret",
                targets=[ip_sync.Target(security_group_id="sg-1", rule_identifier="sgr-1")],
            )
        ]

        with patch("ip_sync.resolve_ip_consensus", return_value=("2.2.2.2", "majority", {})), patch(
            "ip_sync.load_state", return_value={"targets": {"acc|cn-hangzhou|sg-1:sgr-1": {"last_ip": "1.1.1.1", "updated_at": 1}}}
        ), patch("ip_sync.save_state", return_value=None), patch(
            "ip_sync.execute_update_with_retry", return_value=(True, 1, "ok")
        ), patch("ip_sync.send_summary_notification", return_value=("sent", 1, "ok")), patch(
            "ip_sync._log_line"
        ) as mock_log:
            code = ip_sync.run_cycle(cfg)

        self.assertEqual(ip_sync.EXIT_OK, code)
        self.assertTrue(any("step4：发送变更通知" in str(c.args[1]) for c in mock_log.call_args_list))


if __name__ == "__main__":
    unittest.main()
